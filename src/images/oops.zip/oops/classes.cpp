#include<iostream>

using namespace std;

class complex{
private:
    int real,imag;
public:
    void setValue(){
        cout<<endl<<"Enter the real Part\t";
        cin>>real;
        cout<<endl<<"Enter the imaginary Part\t";
        cin>>imag;
    }
    void displayData(){
    cout<<endl<<"sum is = "<<real<<" + "<<imag<<"i"<<endl;
    }

    complex add(complex);
};

complex complex::add(complex n)
{
    complex temp;
    temp.real=real+n.real;
    temp.imag=imag+n.imag;
    return temp;
}
// first complex is for return type;
//second complex is for class
int main(){
complex n1,n2,n3;
n1.setValue();
n2.setValue();
n3=n2.add(n1);
n3.displayData();
}










