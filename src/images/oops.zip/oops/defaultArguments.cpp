#include<iostream>

using namespace std;

int add(int,int,int=0);

int add(int x,int y,int z){
return x+y+z;
}

int multiply(int x,int y,int z=1);

int multiply(int x,int y,int z){
return x*y*z;
}


int main(){
int a,b,c,sum,pro;
cout<<"\nEnter Two number to add and multiply"<<endl;
cin>>a>>b;
sum=add(a,b);
pro=multiply(a,b);
cout<<"sum = "<<sum<<endl;
cout<<"product = "<<pro<<endl;
cout<<"Enter Three number to add and multiply"<<endl;
cin>>a>>b>>c;
pro=multiply(a,b,c);
sum=add(a,b,c);
cout<<"sum = "<<sum<<endl;
cout<<"product = "<<pro<<endl;
}
