#include<iostream>

using namespace std;

class Complex
{
private:
    int real,img;
public:
    void setData(int x,int y)
    {
        real=x;
        img=y;
    }
    void showData(){
    cout<<"\nreal part = "<<real<<"\n\nimaginary part = "<<img<<endl;
    }
    Complex operator =(Complex &c){
    Complex temp;
    c.real = real;
    c.img = img;
    }
};

int main(){
Complex c1,c2;
c1.setData(3,4);
c1=c2;
c2.showData();
}
