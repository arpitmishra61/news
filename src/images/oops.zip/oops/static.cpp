#include<iostream>

using namespace std;

class Account
{
private:
    int balance;
    static int roi;
public:
    void setBalance(int b)
    {
        balance=b;
    }
    void calcInterest(int year){
    int i = (balance*roi*year)/100;;
    balance=balance+i;
    }
    void showBalance(){
    cout<<endl<<"Balance is = "<<balance;
    }
    static void setRoi(float r)
    {
        roi=r;
    }
};

int Account::roi;

int main(){

Account a1,a2;
a1.setBalance(4000);
a1.showBalance();
cout<<endl<<"Enter years for saving\t";
int y;
cin>>y;
a1.setRoi(4.5f);
a1.calcInterest(y);
a1.showBalance();
}
