#include<iostream>

using namespace std;

class Int
{
private:
    int num;
public:
    void setData(int x)
    {
        num=x;
    }
    void showData(){
    cout<<"\n Number is = "<<num<<endl;
    }
    Int operator %(Int c){
    Int temp;
    temp.num = num%c.num;
    return(temp);
    }
};

int main(){
Int c1,c2,c3;
c1.setData(10);
c2.setData(4);
c3=c1%c2;
c3.showData();
}
