#include<iostream>

using namespace std;

class Complex{
private:
    int real, img;
public:
    Complex(int a,int b)
    {
        real=a;
        img=b;
    }
    Complex(Complex &c)
    {
        real=c.real;
        img=c.img;
    }
    void showData(){
    cout<<"real part = "<<real<<endl<<"\nimaginary part = "<<img<<endl;
    }
};
int main(){
Complex c1(3,4);
Complex c2=c1;
c2.showData();
}
