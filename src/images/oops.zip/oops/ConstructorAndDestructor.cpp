#include<iostream>
#include<string.h>
#include<stdio.h>
using namespace std;

class student{
private:
    int id;
    char name[50];
    char add[50];
    static int count;
public:
    student(int i,char nm[],char addr[]){
        id=i;
        strcpy(name,nm);
        strcpy(add,addr);
        count++;
    }
    ~student(){
    count--;
    }
    void displayData(){
    cout<<"Name   : "<<name<<endl;
    cout<<"id     : "<<id<<endl;
    cout<<"address: "<<add<<endl;
    }
    static void DisplayTotal()
    {
        cout<<endl<<"Total number of student is "<<count<<endl;
    }

};

int student:: count=0;


/*-------------------------------------------------------------------------*/

student* getInput(){
int id;char name[50],add[100];
cout<<endl<<"enter name\t";
fflush(stdin);
gets(name);
cout<<endl<<"enter id\t";
cin>>id;
cout<<endl<<"enter address\t";
fflush(stdin);
gets(add);
student *ptr = new student(id,name,add);
return ptr;
}

/*-------------------------------------------------------------------------*/

int main(){
student *arr[1000];
int ex=1;
int i=0;
int ch;
while(ex){
cout<<endl<<"Please choose your option"<<endl;
cout<<"1.Enter A record"<<endl;
cout<<"2.Show total no of student"<<endl;
cout<<"3.Exit"<<endl;
cin>>ch;

    switch(ch){
case 1 :
    arr[i] =getInput();
    i++;
    break;

case 2:
    student::DisplayTotal();
    break;

case 3: ex=0;
    }
}


}
