#include<iostream>

using namespace std;


void swapByReference(int&,int&);




void swapByReference(int &x ,int &y){
int temp=x;
x=y;
y=temp;
}

int main(){
int x,y;
cout<<"Enter First number\n";
cin>>x;
cout<<"Enter Second number\n";
cin>>y;
swapByReference(x,y);
cout<<endl<<"after swap by reference\n"<<" First number = "<<x<<" Second number = "<<y<<endl;
}
